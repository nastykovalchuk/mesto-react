import { useState, useEffect } from "react";
import Footer from "./footer";
import Header from "./Header";
import Main from "./main";
import PopupWithForm from "./PopupWithForm";
import ImagePopup from "./ImagePopup";
import { CurrentUserContext } from "../context/CurrentUserContext";
import Api from "../utils/Api";
import EditProfilePopup from "./EditProfilePopup";
import EditAvatarPopup from "./EditAvatarPopup";

function App() {
  const [isEditProfilePopupOpen, setIsEditProfilePopupOpen] = useState(false);
  const [isAddPlacePopupOpen, setIsAddPlacePopupOpen] = useState(false);
  const [isEditAvatarPopupOpen, setIsEditAvatarPopupOpen] = useState(false);
  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState({});
  const [currentUser, setCurrentUser] = useState({});
  const [cards, setCards] = useState([]);

  function handleEditAvatarClick() {
    setIsEditAvatarPopupOpen(true);
  }
  function handleEditProfileClick() {
    setIsEditProfilePopupOpen(true);
  }
  function handleAddPlaceClick() {
    setIsAddPlacePopupOpen(true);
  }
  function handleDeliteClick() {
    setIsDeletePopupOpen(true);
  }
  function handleCardClick(card) {
    setSelectedCard(card);
  }

  function handleUpdateUser(data) {
    Api.patchUserInfo(data)
      .then((res) => {
        setCurrentUser(res);
      })
      .catch((error) => console.log(error));
    closeAllPopups();
  }

  function handleUpdateAvatar(data) {
    console.log(data);
    Api.patchAvatar(data)
      .then((res) => {
        setCurrentUser(res);
      })
      .catch((error) => console.log(error));
    closeAllPopups();
  }

  function handleCardLike(card) {
    const isLiked = card.likes.some((i) => i._id === currentUser._id);

    Api.changeLikeCardStatus(card._id, isLiked)
      .then((newCard) => {
        setCards((state) =>
          state.map((c) => (c._id === card._id ? newCard : c))
        );
      })
      .then(console.log(cards))
      .catch((error) => console.log(error));
  }
  function closeAllPopups() {
    setIsEditAvatarPopupOpen(false);
    setIsEditProfilePopupOpen(false);
    setIsAddPlacePopupOpen(false);
    setIsDeletePopupOpen(false);
    setSelectedCard({});
  }

  useEffect(() => {
    Api.getUserInfo()
      .then((res) => {
        setCurrentUser(res);
      })
      .catch((error) => console.log(error));

    Api.getCards()
      .then((res) => {
        setCards(res);
      })
      .catch((error) => console.log(error));

    // Api.setUserAvatar()
    //   .then((res) => {
    //     handleUpdateAvatar(res);
    //   })
    //   .catch((error) => console.log(error));
  }, []);

  return (
    <CurrentUserContext.Provider value={currentUser}>
      <div className="page__content">
        <Header />
        <Main
          cards={cards}
          onEditProfile={handleEditProfileClick}
          onAddPlace={handleAddPlaceClick}
          onEditAvatar={handleEditAvatarClick}
          onEditDelite={handleDeliteClick}
          onCardClick={handleCardClick}
          onCardLike={handleCardLike}
        />
        <EditAvatarPopup
          isOpen={isEditAvatarPopupOpen}
          onClose={closeAllPopups}
          onUpdateAvatar={handleUpdateAvatar}
        />

        <EditProfilePopup
          closeAllPopups={closeAllPopups}
          isEditProfilePopupOpen={isEditProfilePopupOpen}
          onUpdateUser={handleUpdateUser}
        />
        <PopupWithForm
          name={"placePopup"}
          title={"Новое место"}
          isOpen={isAddPlacePopupOpen}
          onClose={closeAllPopups}
          buttonText={"Создать"}
        >
          <>
            <label>
              <input
                className="popup__input"
                id="placeName-input"
                name="name"
                type="text"
                placeholder="Название"
                required
              />
              <span className="popup__input-error placeName-input-error"></span>
            </label>
            <label className="popup__field">
              <input
                className="popup__input"
                id="link-input"
                name="name"
                type="url"
                placeholder="Ссылка на картинку"
                required
              />
              <span className="popup__input-error link-input-error"></span>
            </label>
          </>
        </PopupWithForm>

        <PopupWithForm
          name={"popup_delite_place"}
          title={"Вы уверены?"}
          isOpen={isDeletePopupOpen}
          onClose={closeAllPopups}
          buttonText={"Да"}
        />
        <ImagePopup card={selectedCard} onClose={closeAllPopups} />
        <Footer />
      </div>
    </CurrentUserContext.Provider>
  );
}

export default App;
